module.exports = function hang () {
    return new Promise(() => {
        // NOTE: Hang forever.
    });
};
