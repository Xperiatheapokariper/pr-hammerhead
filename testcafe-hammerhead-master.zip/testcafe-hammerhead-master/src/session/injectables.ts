import SERVICE_ROUTES from '../proxy/service-routes';

export const SCRIPTS = [SERVICE_ROUTES.hammerhead];
