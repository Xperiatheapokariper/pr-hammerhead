export default {
    hammerhead:       '/hammerhead.js',
    task:             '/task.js',
    iframeTask:       '/iframe-task.js',
    messaging:        '/messaging',
    transportWorker:  '/transport-worker.js',
    workerHammerhead: '/worker-hammerhead.js',
};
