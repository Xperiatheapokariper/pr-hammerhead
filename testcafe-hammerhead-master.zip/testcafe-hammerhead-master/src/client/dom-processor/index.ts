import DomAdapter from './client-dom-adapter';
import DomProcessor from '../../processing/dom/index';

export default new DomProcessor(new DomAdapter());
