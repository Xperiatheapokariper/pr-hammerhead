enum DefaultTarget { // eslint-disable-line no-shadow
    form = '_self',
    linkOrArea = '_self',
    windowOpen = '_blank'
}

export default DefaultTarget;
