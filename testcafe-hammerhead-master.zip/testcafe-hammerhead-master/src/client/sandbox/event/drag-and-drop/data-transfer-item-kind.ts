// https://html.spec.whatwg.org/multipage/interaction.html#the-drag-data-item-kind
export default {
    string: 'string',
    file:   'file',
};
