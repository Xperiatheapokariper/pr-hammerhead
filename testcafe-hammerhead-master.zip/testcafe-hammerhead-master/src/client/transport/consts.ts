export const SET_INITIAL_WORKER_SETTINGS_CMD = 'hammerhead|transport|set-initial-worker-settings';
export const HANDLE_PORT_CMD                 = 'hammerhead|transport|handle-port';
