export const SET_SERVICE_WORKER_SETTINGS = 'hammerhead|set-service-worker-settings';
