document.location = 'https://some.com/';
